﻿using ZadanieTabele;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
class Program
{
    static void Main()
    {
        using (var context = new ApplicationDbContext())
        {
            // CREATE
            var author = new Author { Name = "John Doe" };
            var book = new Book { Title = "Sample Book", Publisher = new Publisher { Name = "Sample Publisher" } };
            author.AuthorBooks = new List<AuthorBook> { new AuthorBook { Book = book } };
            context.Authors.Add(author);
            context.SaveChanges();

            // READ
            Console.WriteLine("Authors and their Books:");
            foreach (var a in context.Authors.Include(a => a.AuthorBooks).ThenInclude(ab => ab.Book))
            {
                Console.WriteLine($"Author: {a.Name}");
                foreach (var ab in a.AuthorBooks)
                {
                    Console.WriteLine($"  Book: {ab.Book.Title}");
                }
            }

            // UPDATE
            var authorToUpdate = context.Authors.First();
            authorToUpdate.Name = "Updated Author";
            context.SaveChanges();

            // DELETE
            var authorToDelete = context.Authors.First();
            context.Authors.Remove(authorToDelete);
            context.SaveChanges();
        }
    }
}